package games;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import static java.lang.Math.sqrt;
import java.util.Random;
import javax.swing.JLabel;
import java. util. Arrays;
import javax.swing.Timer;

/**
 * This class implements the game 2048, a GUI for the game and an evolutionary algorithm
 * for an AI for the game.
 * @author Bruno Guarise - 9313429
 * @author Lucas Guarise - 9266406
 * @author Pedro Balan   - 9266726
 * @version 1.0
 */

public class Game2048 extends javax.swing.JFrame {
    
    static final int N_CHRO = 9; //Number of parameters per chromosome
    static final int N_TRY = 1000; //Number of runs per chromosome
    static final int N_GEN = 100; //Number of generations tested
    private final boolean _view;
    private final boolean _ai;
    private final boolean _is_training;
    private final SaveMe Save = new SaveMe(N_CHRO);
    
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    
    /**
     * 
     */
    public Game2048(boolean view, boolean ai, boolean is_training) {
        //Type of execution variables
        _view = view;
        _is_training = is_training;
        _ai = ai;
        
        //Tries to load previews fittest chromosome
        Save.loadFittest();
        System.arraycopy(Save.getFittest(), 0, fittest, 0, N_CHRO);
        
        //Starts the GUI
        if(_view)
            initComponents();
        
        //Starts AI auto play for demonstration of results
        if(_view && !_is_training && ai)
            init_actionListner();
        
        //Starts new game
        createFieldMap();
        startGame();
        
        //Starts execution mode of evolutionary algorithm
        if(_is_training && _ai)
            init_evolutionaryAlgorithm();
        
    }
    //</editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRestart;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JLabel lblScoreGame;
    private javax.swing.JLabel lblScoreMax;
    private javax.swing.JLabel pos_1_1;
    private javax.swing.JLabel pos_1_2;
    private javax.swing.JLabel pos_1_3;
    private javax.swing.JLabel pos_1_4;
    private javax.swing.JLabel pos_2_1;
    private javax.swing.JLabel pos_2_2;
    private javax.swing.JLabel pos_2_3;
    private javax.swing.JLabel pos_2_4;
    private javax.swing.JLabel pos_3_1;
    private javax.swing.JLabel pos_3_2;
    private javax.swing.JLabel pos_3_3;
    private javax.swing.JLabel pos_3_4;
    private javax.swing.JLabel pos_4_1;
    private javax.swing.JLabel pos_4_2;
    private javax.swing.JLabel pos_4_3;
    private javax.swing.JLabel pos_4_4;
    // End of variables declaration//GEN-END:variables
	
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblScoreGame = new javax.swing.JLabel();
        lblScoreMax = new javax.swing.JLabel();
        pos_1_1 = new javax.swing.JLabel();
        pos_1_2 = new javax.swing.JLabel();
        pos_1_3 = new javax.swing.JLabel();
        pos_1_4 = new javax.swing.JLabel();
        pos_2_1 = new javax.swing.JLabel();
        pos_2_2 = new javax.swing.JLabel();
        pos_2_3 = new javax.swing.JLabel();
        pos_2_4 = new javax.swing.JLabel();
        pos_3_1 = new javax.swing.JLabel();
        pos_3_2 = new javax.swing.JLabel();
        pos_3_3 = new javax.swing.JLabel();
        pos_3_4 = new javax.swing.JLabel();
        pos_4_1 = new javax.swing.JLabel();
        pos_4_2 = new javax.swing.JLabel();
        pos_4_3 = new javax.swing.JLabel();
        pos_4_4 = new javax.swing.JLabel();
        btnRestart = new javax.swing.JButton();
        lblResultado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("2048");
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        lblScoreGame.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblScoreGame.setText("Score: 0");

        lblScoreMax.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblScoreMax.setText("Max: 0");

        pos_1_1.setBackground(new java.awt.Color(153, 153, 153));
        pos_1_1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_1_1.setForeground(new java.awt.Color(255, 255, 255));
        pos_1_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_1_1.setOpaque(true);

        pos_1_2.setBackground(new java.awt.Color(153, 153, 153));
        pos_1_2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_1_2.setForeground(new java.awt.Color(255, 255, 255));
        pos_1_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_1_2.setOpaque(true);

        pos_1_3.setBackground(new java.awt.Color(153, 153, 153));
        pos_1_3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_1_3.setForeground(new java.awt.Color(255, 255, 255));
        pos_1_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_1_3.setOpaque(true);

        pos_1_4.setBackground(new java.awt.Color(153, 153, 153));
        pos_1_4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_1_4.setForeground(new java.awt.Color(255, 255, 255));
        pos_1_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_1_4.setOpaque(true);

        pos_2_1.setBackground(new java.awt.Color(153, 153, 153));
        pos_2_1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_2_1.setForeground(new java.awt.Color(255, 255, 255));
        pos_2_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_2_1.setOpaque(true);

        pos_2_2.setBackground(new java.awt.Color(153, 153, 153));
        pos_2_2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_2_2.setForeground(new java.awt.Color(255, 255, 255));
        pos_2_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_2_2.setOpaque(true);

        pos_2_3.setBackground(new java.awt.Color(153, 153, 153));
        pos_2_3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_2_3.setForeground(new java.awt.Color(255, 255, 255));
        pos_2_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_2_3.setOpaque(true);

        pos_2_4.setBackground(new java.awt.Color(153, 153, 153));
        pos_2_4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_2_4.setForeground(new java.awt.Color(255, 255, 255));
        pos_2_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_2_4.setOpaque(true);

        pos_3_1.setBackground(new java.awt.Color(153, 153, 153));
        pos_3_1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_3_1.setForeground(new java.awt.Color(255, 255, 255));
        pos_3_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_3_1.setOpaque(true);

        pos_3_2.setBackground(new java.awt.Color(153, 153, 153));
        pos_3_2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_3_2.setForeground(new java.awt.Color(255, 255, 255));
        pos_3_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_3_2.setOpaque(true);

        pos_3_3.setBackground(new java.awt.Color(153, 153, 153));
        pos_3_3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_3_3.setForeground(new java.awt.Color(255, 255, 255));
        pos_3_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_3_3.setOpaque(true);

        pos_3_4.setBackground(new java.awt.Color(153, 153, 153));
        pos_3_4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_3_4.setForeground(new java.awt.Color(255, 255, 255));
        pos_3_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_3_4.setOpaque(true);

        pos_4_1.setBackground(new java.awt.Color(153, 153, 153));
        pos_4_1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_4_1.setForeground(new java.awt.Color(255, 255, 255));
        pos_4_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_4_1.setOpaque(true);

        pos_4_2.setBackground(new java.awt.Color(153, 153, 153));
        pos_4_2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_4_2.setForeground(new java.awt.Color(255, 255, 255));
        pos_4_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_4_2.setOpaque(true);

        pos_4_3.setBackground(new java.awt.Color(153, 153, 153));
        pos_4_3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_4_3.setForeground(new java.awt.Color(255, 255, 255));
        pos_4_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_4_3.setOpaque(true);

        pos_4_4.setBackground(new java.awt.Color(153, 153, 153));
        pos_4_4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pos_4_4.setForeground(new java.awt.Color(255, 255, 255));
        pos_4_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pos_4_4.setOpaque(true);

        btnRestart.setText("Restart Game");
        btnRestart.setFocusable(false);
        btnRestart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRestartActionPerformed(evt);
            }
        });

        lblResultado.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pos_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pos_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(pos_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(pos_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblScoreGame))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblScoreMax)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(pos_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(pos_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pos_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pos_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRestart)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblScoreGame)
                    .addComponent(lblScoreMax))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pos_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pos_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pos_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pos_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pos_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRestart)
                    .addComponent(lblResultado))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // </editor-fold>
      
    //<editor-fold defaultstate="collapsed" desc="Events">
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        setLocationRelativeTo(null);
        this.getContentPane().setBackground(getBackgroundColor("BG"));
        lblScoreGame.setForeground(getForegroundColor("BG"));
        lblScoreMax.setForeground(getForegroundColor("BG"));
    }//GEN-LAST:event_formWindowOpened

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        if (lblResultado.getText().isEmpty()) {
            Point Move = new Point();
            if(evt.getKeyCode() == KeyEvent.VK_UP) {
                Move.y = 1;
            }
            else if(evt.getKeyCode() == KeyEvent.VK_DOWN) {
                Move.y = -1;
            }
            else if(evt.getKeyCode() == KeyEvent.VK_LEFT) {
                Move.x = 1;
            }
            else if(evt.getKeyCode() == KeyEvent.VK_RIGHT) {
                Move.x = -1;
            }

            if (Move.x != 0 || Move.y != 0) {
                moveNumbers(Move);
            }
        }
    }//GEN-LAST:event_formKeyPressed
    private void init_actionListner(){
        ActionListener actListner = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event) {
                System.arraycopy(fittest, 0, population[0], 0, N_CHRO);
                test_chromosome = 0;
                if(!isGameLost()){
                    Point nextMove;
                    nextMove = calcNextMove();
                    moveNumbers(nextMove);
                }
            }

        };
        Timer timer = new Timer(500, actListner);
        timer.start();      
    }
    
    private void btnRestartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRestartActionPerformed
        clearGame();
        startGame();
    }//GEN-LAST:event_btnRestartActionPerformed
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="GameFuntions">
   private Random randomSeed = new java.util.Random();
    private int gamePositions[][] = new int[4][4];
    private JLabel[][] gameViewPositions = new JLabel[4][4];
    private Number scoreGame = 0;
    private Number scoreMax = 0;

    /**
    * This method is used to create the field map for both the 
    * logical and the visual parts of the program. The logical
    * part (gamePositions) will be used along the program for
    * verifications, while the visual part (gameViewPositions)
    * will be used to plot the game graphically.
    */
    private void createFieldMap() {
        gamePositions[0][0] = 0;
        gamePositions[0][1] = 0;
        gamePositions[0][2] = 0;
        gamePositions[0][3] = 0;
        gamePositions[1][0] = 0;
        gamePositions[1][1] = 0;
        gamePositions[1][2] = 0;
        gamePositions[1][3] = 0;
        gamePositions[2][0] = 0;
        gamePositions[2][1] = 0;
        gamePositions[2][2] = 0;
        gamePositions[2][3] = 0;
        gamePositions[3][0] = 0;
        gamePositions[3][1] = 0;
        gamePositions[3][2] = 0;
        gamePositions[3][3] = 0;
        
        
        if(_view){
            gameViewPositions[0][0] = pos_1_1;
            gameViewPositions[0][1] = pos_1_2;
            gameViewPositions[0][2] = pos_1_3;
            gameViewPositions[0][3] = pos_1_4;
            gameViewPositions[1][0] = pos_2_1;
            gameViewPositions[1][1] = pos_2_2;
            gameViewPositions[1][2] = pos_2_3;
            gameViewPositions[1][3] = pos_2_4;
            gameViewPositions[2][0] = pos_3_1;
            gameViewPositions[2][1] = pos_3_2;
            gameViewPositions[2][2] = pos_3_3;
            gameViewPositions[2][3] = pos_3_4;
            gameViewPositions[3][0] = pos_4_1;
            gameViewPositions[3][1] = pos_4_2;
            gameViewPositions[3][2] = pos_4_3;
            gameViewPositions[3][3] = pos_4_4;
        }
    }
    
    /**
    * This method moves the numbers in the field map, merging the possible numbers
    * (restricting these numbers to only one merge per turn), and checking if the
    * player has any moves left or if the player has won the game.
    * @param mov This varible represents the direction in which the player wants to
    * move the numbers on the field map. The values for mov relative to each direction
    * are defined in the method 'formKeyPressed'
    */
    private void moveNumbers(Point mov) {
        Point pos = new Point();
        Number tmpNum = 0;
        int endPos = 0;
        boolean hasMoves = false;
        boolean gameWon = false;
        
        if (mov.y == 1) {
            pos.y = 0;
            pos.x = 0;
            endPos = 4;
        }
        else if (mov.y == -1) {
            pos.y = 3;
            pos.x = 0;
            endPos = -1;
        }
        else if (mov.x == 1) {
            pos.y = 0;
            pos.x = 0;
            endPos = 4;
        }
        else if (mov.x == -1) {
            pos.y = 0;
            pos.x = 3;
            endPos = -1;
        }
        
        if (mov.y != 0) {
            for (;pos.x < 4; pos.x++){
                for (int y1 = pos.y; y1 != endPos; y1 += mov.y){
                    for (int y2 = y1 + mov.y; y2 != endPos; y2 += mov.y) {
                        if (isPositionEmpty(y1,pos.x)) {
                            if (!isPositionEmpty(y2,pos.x)) {
                                  gamePositions[y1][pos.x] = gamePositions[y2][pos.x];
                                  gamePositions[y2][pos.x] = 0;
                                hasMoves = true;
                            }
                        }
                        else if (gamePositions[y1][pos.x]==gamePositions[y2][pos.x]) {
                            tmpNum = gamePositions[y1][pos.x]*2;
                            gamePositions[y1][pos.x]*= 2;
                            gamePositions[y2][pos.x]= 0;
                            addScore(tmpNum.intValue());
                            hasMoves = true;
                            if (tmpNum.intValue() == 2048)
                                gameWon = true;
                            break;
                        }
                        else if (!isPositionEmpty(y2,pos.x)) {
                            break;
                        }
                    }
                }
            }
        }
        else if (mov.x != 0) {
            for (;pos.y < 4; pos.y++){
                for (int x1 = pos.x; x1 != endPos; x1 += mov.x){
                    for (int x2 = x1 + mov.x; x2 != endPos; x2 += mov.x) {
                        if (isPositionEmpty(pos.y,x1)) {
                            if (!isPositionEmpty(pos.y,x2)) {
                                gamePositions[pos.y][x1]= gamePositions[pos.y][x2];
                                gamePositions[pos.y][x2] = 0;
                                hasMoves = true;
                            }
                        }
                        else if (gamePositions[pos.y][x1] == gamePositions[pos.y][x2]) {
                            tmpNum = gamePositions[pos.y][x1] * 2;
                            gamePositions[pos.y][x1] = gamePositions[pos.y][x1] * 2;
                            gamePositions[pos.y][x2] = 0;
                            addScore(tmpNum.intValue());
                            hasMoves = true;
                            break;
                        }
                        else if (!isPositionEmpty(pos.y,x2)) {
                            break;
                        }
                    }
                }
            }
        }
        
        if (hasMoves) {
            setNewNumber();
            if(_view)
                setFieldColors();
        }
        
        if (gameWon) {
            
            if(_view){
                lblResultado.setText("You Win!");
                lblResultado.setForeground(getForegroundColor("WIN"));
            }
        } else if (isGameLost()) {
            if(_view){
                lblResultado.setText("You Lost!");
                lblResultado.setForeground(getForegroundColor("LOST"));
            }
        }
    }
    
    /**
    * This method starts the game. It generates a new number
    * in a random spot on the field map and displays the field
    * map graphically if the boolean _view is true.
    */
    private void startGame() {
        Point pos = getRandomPosition();
        gamePositions[pos.y][pos.x]= 2;
        
        setNewNumber();
        if(_view)
            setFieldColors();
    }
    
    /**
    * This method clears the field map, setting all of its
    * positions to zero. If the boolean _view is set to true
    * is displays the empty field map graphically.
    */
    private void clearGame() {
        for (int y = 0; y <= 3; y++) {
            for (int x = 0; x <=3; x++) {
                gamePositions[y][x]= 0;
            }
        }
        clearScore();
        if(_view){
            updateViewPositions();
            setFieldColors();
        }
    }
    
    /**
    * This method adds the points of new combinations made by
    * the player to the score of the current game. It also
    * updates the max score of all games played so far.
    * @param points This is the number of points to be added to the total score        
    */
    private void addScore(int points) {
        scoreGame = scoreGame.intValue() + points;
        //System.out.printf("%d\n",scoreGame);
        if (scoreGame.intValue() > scoreMax.intValue())
            scoreMax = scoreGame;
        if(_view){
            lblScoreGame.setText("Score: " + scoreGame.toString());
            lblScoreMax.setText("Max: " + scoreMax.toString());
        }
    }
    
    /**
    * This method clears the score at the beggining of
    * every game, setting it to zero.
    */
    private void clearScore() {
        scoreGame = 0;
        if(_view){
            lblScoreGame.setText("Score: " + scoreGame.toString());
            lblResultado.setText("");
        }
    }
    
    /**
    * This method sets the colors of both the background and
    * the foreground of the graphically displayed field map.
    */
    private void setFieldColors() {
        for (int y = 0; y <= 3; y++) {
            for (int x = 0; x <=3; x++) {
                gameViewPositions[y][x].setBackground(getBackgroundColor(gameViewPositions[y][x].getText()));
                gameViewPositions[y][x].setForeground(getForegroundColor(gameViewPositions[y][x].getText()));
            }
        }
    }
    
    /**
    * This method generates a new number in a random
    * position of the field map, as long as it's empty.
    * There is a 20% chance that this new number
    * is a 4 and an 80% chance that it's a 2.
    */
    private void setNewNumber() {
       if (!isFieldFull())
       {
            Point pos;
            int percent = randomSeed.nextInt(101);

            do {            
                pos = getRandomPosition();
            } while (!isPositionEmpty(pos));

            if (percent > 80)
                gamePositions[pos.y][pos.x]= 4;
            else
                gamePositions[pos.y][pos.x]= 2;
       }
       if(_view)
            updateViewPositions();
    }
    
    /**
    * This method check if a given position of the field
    * map is empty or not, and returns a boolean confirming
    * the result.
    * @param pos This parameter is the position of the field map to be checked
    * @return boolean This returns if the given position (pos) is empty or not
    */
    private boolean isPositionEmpty(Point pos) {
        if(gamePositions[pos.y][pos.x]== 0)
            return true;
        return false;
    }
    
    /**
    * This method check if a given position of the field
    * map is empty or not, and returns a boolean confirming
    * the result.
    * @param y This parameter is the y position of the field map to be checked
    * @param x This parameter is the x position of the field map to be checked
    * @return boolean This returns if the given position is empty or not
    */
    private boolean isPositionEmpty(int y, int x) {
        if(gamePositions[y][x]== 0)
            return true;
        return false;
    }
    
    /**
    * This method checks every position of the field map 
    * and returns a boolean checkin if the field map
    * is full or not.
    * @return boolean This returns if the field map is full or not
    */
    private boolean isFieldFull() {
        for (int y = 0; y <= 3; y++) {
            for (int x = 0; x <=3; x++) {
               if(isPositionEmpty(y, x)) {
                   return false;
               }
            }
        }
        return true;
    }
    
    /**
    * This method is used to check if the player has turns to
    * play or if he/she has lost the game.
    * First, it checks is the field map is full, and if it is,
    * it check if there are no more possible plays.
    * @return boolean This returns if the game is lost or not
    */
    private boolean isGameLost() {
        if (!isFieldFull())
            return false;
        else {
            for (int x = 0; x < 4; x++) {
                for (int y = 0; y < 4; y++) {
                    if (x-1 >= 0) {
                        if (gamePositions[y][x]==gamePositions[y][x-1])
                            return false;
                    }
                    if (x+1 <= 3) {
                        if (gamePositions[y][x]== gamePositions[y][x+1])
                            return false;
                    }
                    if (y-1 >= 0) {
                        if (gamePositions[y][x] == gamePositions[y-1][x])
                            return false;
                    }
                    if (y+1 <= 3) {
                        if (gamePositions[y][x] == gamePositions[y+1][x])
                            return false;
                    }
                }
            }
            return true;
        }
    }
    
    /**
    * This method updates the positions of the graphically displayed
    * field map, based on the values of the logical field map
    */
    private void updateViewPositions(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if (gamePositions[i][j] == 0)
                    gameViewPositions[i][j].setText("");
                else
                    gameViewPositions[i][j].setText(Integer.toString(gamePositions[i][j]));
            }
        }
    }
    
    /**
    * This method returns an int corresponding to an input hexadecimal string
    * @param hex This is the input string that will be converted to an int value
    * @return int This is the int equivalent of the input String (hex)
    */
    private int hexToInt(String hex) {
        return Integer.parseInt(hex, 16);
    }
    
    /**
    * This method returns a random position in the field map
    * @return Point This is a random position in the field map
    */
    private Point getRandomPosition() {
       Point p = new java.awt.Point(); 
       p.y = randomSeed.nextInt(4);
       p.x = randomSeed.nextInt(4);
       return p;
    }
    
    /**
    * This method returns a Color based on an input string
    * @param value This is the input string that will represent the desired Background Color
    * @return Color This is the Background Color that was represented by the input string (value)
    */
    private Color getBackgroundColor(String value) {
        switch (value) {
            case "BG":
                return new Color(hexToInt("baac9f"));
            case "2":
                return new Color(hexToInt("eee4d9"));
            case "4":
                return new Color(hexToInt("ede0c8"));
            case "8":
                return new Color(hexToInt("f2b179"));
            case "16":
                return new Color(hexToInt("f59563"));
            case "32":
                return new Color(hexToInt("f57c5f"));
            case "64":
                return new Color(hexToInt("f65e3c"));
            case "128":
                return new Color(hexToInt("edcf72"));
            case "256":
                return new Color(hexToInt("eccb60"));
            case "512":
                return new Color(hexToInt("ecc850"));
            case "1024":
                return new Color(hexToInt("edc53f"));
            case "2048":
                return new Color(hexToInt("edc22e"));
            default:
                return new Color(hexToInt("cdc0b4"));
        }
    }
    
    /**
    * This method returns a Color based on an input string
    * @param value This is the input string that will represent the desired Foreground Color
    * @return Color This is the Foreground Color that was represented by the input string (value)
    */
    private Color getForegroundColor(String value) {
        switch (value) {
            case "BG":
                return new Color(hexToInt("ffffff"));
            case "WIN":
                return new Color(hexToInt("008000"));
            case "LOST":
                return new Color(hexToInt("d00000"));
            case "2":
                return new Color(hexToInt("776e65"));
            case "4":
                return new Color(hexToInt("776e65"));
            case "8":
                return new Color(hexToInt("f9f6f2"));
            case "16":
                return new Color(hexToInt("f9f6f2"));
            case "32":
                return new Color(hexToInt("f9f6f2"));
            case "64":
                return new Color(hexToInt("f9f6f2"));
            case "128":
                return new Color(hexToInt("f9f6f2"));
            case "256":
                return new Color(hexToInt("f9f6f2"));
            case "512":
                return new Color(hexToInt("f9f6f2"));
            case "1024":
                return new Color(hexToInt("f9f6f2"));
            case "2048":
                return new Color(hexToInt("f9f6f2"));
            default:
                return new Color(hexToInt("ffffff"));
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="EvolutionaryFuntions">
    private float population[][] = new float[20][N_CHRO];
    private float fittest[] = new float[N_CHRO];
    private int test_chromosome = 0; // Index of the chromosome being tested
    private float test_score[] = new float[20]; //Scores for a generation
    private int generation = 0;
    
    //Varibles to print max result during a evolutionary run
    private Number scoreRunMax = 0;
    private int bestRunMap[][] = new int[4][4];
    
    /**
     * This method implements the evolutionary algorithm used 
     * in the improvement of the game AI.
     */
    private void init_evolutionaryAlgorithm() {
        int trys_score[] = new int[N_TRY];
        int best;
        
        initPopulation(population);
        while(generation < N_GEN){
            //System.out.print(generation + "\n");
            
            //For every chromosome in the population 
            for(int p = 0; p < 20; p++){
                for(int try_ = 0; try_ < N_TRY; try_++){
                    //Run an entire game
                    while (!isGameLost()){
                        Point nextMove;
                        nextMove = calcNextMove();
                        moveNumbers(nextMove);
                    }
                    //Get game score
                    trys_score[try_] = scoreGame.intValue();
                    
                    //Save if max score run, for curiosity purpose only
                    if(scoreGame.intValue()>scoreRunMax.intValue()){
                        scoreRunMax=scoreGame;
                        for(int i =0; i<4;i++){
                            for(int j =0;j<4;j++){
                                bestRunMap[i][j]= gamePositions[i][j];
                            }
                        }
                    }
                    //Reset Game
                    clearGame();
                    startGame();
                }
                // Cuts scores above and below the standard deviation from the average
                // and gets the average of the remaining values
                test_score[p] = (float)sdcut(trys_score);
                //Changes chromosome being tested
                test_chromosome++;
            }
            
            tournament();
            crossing();
            mutation();
            
            test_chromosome = 0;
            generation++;
        }
        
        //Updates the fittest member of the population if it's better then the current fittest member saved
        best = 0;
        for(int i = 0; i < 20; i++){
            if(test_score[best] < test_score[i]){
                best = i;
            }
        }
        if(fittest == null){
            Save.saveFittest(population[best],test_score[best]);
            Save.loadFittest();
        }
        else if(Save.getScore() < test_score[best]){
            System.arraycopy(population[best], 0, fittest, 0, N_CHRO);
            Save.saveFittest(population[best],test_score[best]);
            Save.loadFittest();
        }
    }

    /**
     * This method implements a tournament among the
     * population to select the best individuals.
     */
    private void tournament() {
       for(int i = 0; i < 10; i++){
                //Selects two chromosomes and compares the scores
                if(test_score[i*2] > test_score[i*2 + 1]){
                    population[i] = population[i*2];
                }
                else{
                    population[i] = population[i*2 + 1];
                }
            } 
    }

    /**
     * This method does the crossing between the select
     * chromosomes to generate a new population.
     */
    private void crossing() {
        int h = 0;
        //First round of crossing to generate 5 chromosomes in the new population
        for(int i =10;i<15;i++){
        int rand;
            for(int j=0;j<N_CHRO ;j++){
                rand = randomSeed.nextInt(2);
                if(rand ==1)
                    population[i][j] = population[h][j];
                else
                    population[i][j] = population[h+1][j];
            }
            h += 2;
        }
        h=0;
        int g =9;
        //Second round of crossing to generate 5 more chromosomes in the new population
        for(int i =15;i<20;i++){
            int rand;
            for(int j=0;j<N_CHRO ;j++){
                rand = randomSeed.nextInt(2);
                if(rand ==1)
                    population[i][j] = population[h][j];
                else
                    population[i][j] = population[g][j];
            }
            h++;
            g--;
        }
    }

    /**
     * This method applies the mutation factor in the new
     * population based in a mutation rate. Two types of mutations,
     * a stronger and rarer one, and a weeker and more common one.
     */
    private void mutation() {
        //For each value of the new chromosomes
        for(int i = 10; i < 20 ;i++){
            for(int j = 0; j < N_CHRO ; j++){
                //If a strong mutation occurs
                if(mutationRate(5)){
                    //How big the mutation is
                    population[i][j] *= (randomSeed.nextFloat() - 0.5)*4;
                    //System.out.print(population[i][j] + "\n");
                }
                //If a week mutation occurs
                if(mutationRate(20)){
                    //How big the mutation is
                    population[i][j] += (randomSeed.nextFloat() - 0.5)*2;
                    //System.out.print(population[i][j] + "\n");
                }
            }
        }
    }
    
    /**
     * This method calculates the next move that will be made by the AI in a game.
     */
    private Point calcNextMove() {
        float direction_score = 0, best_score = -99999999;
        Point testMove = new Point(), finalMove = new Point();
        int directionGamePositions[][];
        float c[] = new float[4];
        boolean same;
        
        for(int i = 0; i < 4; i++){
            same = true;
            switch (i){
                case 0:
                    testMove.x = 1;
                    testMove.y = 0;
                    break;
                case 1:
                    testMove.x = 0;
                    testMove.y = 1;
                    break;
                case 2:
                    testMove.x = -1;
                    testMove.y = 0;
                    break;
                case 3:
                    testMove.x = 0;
                    testMove.y = -1;
                    break;
                default:
                    break;
            }
            directionGamePositions = fakeMove(testMove);
            
            for (int a = 0; a < 4; a++) {
                for (int j = 0; j < 4; j++) {
                    if(directionGamePositions[a][j] != gamePositions[a][j]){
                        same = false;
                    }
                }
            }
            direction_score = avaliation(directionGamePositions, population[test_chromosome]);
            //if(i == 0)
                //best_score = direction_score;
            if((!same) && (best_score <= direction_score)){
                best_score = direction_score;
                finalMove.x = testMove.x;
                finalMove.y = testMove.y;
            }
        }
        if(finalMove.x == 0 && finalMove.y == 0){
            System.out.print("Erro best_score :");
            System.out.println(best_score);   
        }
        return finalMove;
    }

    /**
     * This method calculates how the board would stay if moved with the testMove
     * @param testMove is the direction to calculate the movement on the board
     * @return a int[][] that represents the moved board
     */
    private int[][] fakeMove(Point testMove) {
        int possibleGamePositions[][] = new int[4][4]; 
        Point pos = new Point();
        int endPos = 0;
        
        for (int i = 0; i < 4; i++) {
            System.arraycopy(gamePositions[i], 0, possibleGamePositions[i], 0, 4);
        }
        
        if (testMove.y == 1) {
            pos.y = 0;
            pos.x = 0;
            endPos = 4;
        }
        else if (testMove.y == -1) {
            pos.y = 3;
            pos.x = 0;
            endPos = -1;
        }
        else if (testMove.x == 1) {
            pos.y = 0;
            pos.x = 0;
            endPos = 4;
        }
        else if (testMove.x == -1) {
            pos.y = 0;
            pos.x = 3;
            endPos = -1;
        }
        
        if (testMove.y != 0) {
            for (;pos.x < 4; pos.x++){
                for (int y1 = pos.y; y1 != endPos; y1 += testMove.y){
                    for (int y2 = y1 + testMove.y; y2 != endPos; y2 += testMove.y) {
                        if (possibleGamePositions[y1][pos.x] == 0) {
                            if (possibleGamePositions[y2][pos.x] != 0) {
                                  possibleGamePositions[y1][pos.x] = possibleGamePositions[y2][pos.x];
                                  possibleGamePositions[y2][pos.x] = 0;
                            }
                        }
                        else if (possibleGamePositions[y1][pos.x]==possibleGamePositions[y2][pos.x]) {
                            possibleGamePositions[y1][pos.x]*= 2;
                            possibleGamePositions[y2][pos.x]= 0;
                            break;
                        }
                        else if (possibleGamePositions[y2][pos.x] != 0) {
                            break;
                        }
                    }
                }
            }
        }
        else if (testMove.x != 0) {
            for (;pos.y < 4; pos.y++){
                for (int x1 = pos.x; x1 != endPos; x1 += testMove.x){
                    for (int x2 = x1 + testMove.x; x2 != endPos; x2 += testMove.x) {
                        if (possibleGamePositions[pos.y][x1] == 0) {
                            if(possibleGamePositions[pos.y][x2] != 0) {
                                possibleGamePositions[pos.y][x1]= possibleGamePositions[pos.y][x2];
                                possibleGamePositions[pos.y][x2] = 0;
                            }
                        }
                        else if (possibleGamePositions[pos.y][x1] == possibleGamePositions[pos.y][x2]) {
                            possibleGamePositions[pos.y][x1] = possibleGamePositions[pos.y][x1] * 2;
                            possibleGamePositions[pos.y][x2] = 0;
                            break;
                        }
                        else if (possibleGamePositions[pos.y][x2] != 0) {
                            break;
                        }
                    }
                }
            }
        }
        
        return possibleGamePositions;
    }
    
    /**
     * This method generates a punctuation for the next move based in the chromosome
     * and some evaluation parameters to get the best possible move.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @param chromosome a vector of float values which presents our chromosome 
     * @return a float score for the next move.
     */
    private float avaliation(int fieldmap[][], float chromosome[]){      
        float a;
        a = chromosome[0]*emptyPositions(fieldmap) + chromosome[1]*maxPosition(fieldmap)+ chromosome[2]*combinationPossibilites(fieldmap) + chromosome[3]*groupValues(fieldmap) + chromosome[4]*maxEdge(fieldmap) + chromosome[5]*quadraticSum(fieldmap) + chromosome[6]*higherCombination(fieldmap) + chromosome[7]*diferenceNeighborhood(fieldmap) + chromosome[8]*maxCorner(fieldmap);         
        //System.out.print(a + "\n");
        return a;
    }
    
    /**
     * This method returns the difference between the sum of squares of all the positions on the field.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return a int that is the difference of sum of squares of all the positions of the fields
     */
    private int quadraticSum(int fieldmap[][]){
        int sum = 0, current_sum = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
               sum += fieldmap[i][j]*fieldmap[i][j];
               current_sum += gamePositions[i][j] * gamePositions[i][j];
            }
        }
        return sum - current_sum;
    }
    
    /**
     * This method returns the number of empty positions in the board for a possible move.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return a int number of empty positions in field map (fieldmap[i][j]==0).
     */
    private int emptyPositions(int fieldmap[][]){
        int cont = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
              if(fieldmap[i][j]==0)
                  cont++;
            }
        }
        return cont;
    }
    
    /**
     * This method returns the value of the max position in the board for a possible move.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return a int of the max value for a position in fieldmap.
     */
    private int maxPosition(int fieldmap[][]) {
       int max = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
              if(fieldmap[i][j]>max)
                  max = fieldmap[i][j];
            }
        }
        return max; 
    }
    
    /**
     * This method returns the number of combinations on the field map that can be
     * made in the field map.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return an int of the possible combinations in field map.
     */
    private int combinationPossibilites(int fieldmap[][]) {
        int cont = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
              int h = j+1;
              while(h<4){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]==fieldmap[i][h])
                          cont++;
                      break;
                  }
                  h++;
              }
              h = j-1;
              while(h>-1){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]==fieldmap[i][h])
                          cont++;
                      break;
                  }
                  h--;
              }
              h = i+1;
              while(h<4){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]==fieldmap[h][j])
                          cont++;
                      break;
                  }
                  h++;
              }
              h = i-1;
              while(h>-1){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]==fieldmap[h][j])
                          cont++;
                      break;
                  }
                  h--;
              }
            }
        }
        return cont;
    }
    
    /**
     * This method searches for the highest combnation that can be made in the field
     * @param fieldmap is the board to search on.
     * @return a int that is the highest combnation that can be made
     */
    private int higherCombination(int fieldmap[][]) {
        int higher = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
              int h = j+1;
              while(h<4){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]==fieldmap[i][h])
                          if(fieldmap[i][j] + fieldmap[i][h] > higher)
                              higher = fieldmap[i][j] + fieldmap[i][h];
                      break;
                  }
                  h++;
              }
              h = j-1;
              while(h>-1){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]==fieldmap[i][h])
                          if(fieldmap[i][j] + fieldmap[i][h] > higher)
                              higher = fieldmap[i][j] + fieldmap[i][h];
                      break;
                  }
                  h--;
              }
              h = i+1;
              while(h<4){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]==fieldmap[h][j])
                          if(fieldmap[i][j] + fieldmap[i][h] > higher)
                              higher = fieldmap[i][j] + fieldmap[i][h];
                      break;
                  }
                  h++;
              }
              h = i-1;
              while(h>-1){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]==fieldmap[h][j])
                          if(fieldmap[i][j] + fieldmap[i][h] > higher)
                              higher = fieldmap[i][j] + fieldmap[i][h];
                      break;
                  }
                  h--;
              }
            }
        }
        return higher;
    }
    
    /**
     * This method returns the number of times each position has a neighbor value
     * that is immediately smaller than his value.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return int number of neighbor values that is immediately smaller in field map.
     */
    private int groupValues(int fieldmap[][]){
        int cont = 0;
        for(int i=0; i<4;i++){
            for(int j=0; j<4; j++){
              int h = j+1;
              while(h<4){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]== fieldmap[i][h]/2)
                          cont++;
                      break;
                  }
                  h++;
              }
              h = j-1;
              while(h>-1){
                  if(fieldmap[i][h]!= 0){
                      if(fieldmap[i][j]==fieldmap[i][h]/2)
                          cont++;
                      break;
                  }
                  h--;
              }
              h = i+1;
              while(h<4){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]==fieldmap[h][j]/2)
                          cont++;
                      break;
                  }
                  h++;
              }
              h = i-1;
              while(h>-1){
                  if(fieldmap[h][j]!= 0){
                      if(fieldmap[i][j]== fieldmap[h][j]/2)
                          cont++;
                      break;
                  }
                  h--;
              }
            }
        }
        return cont;
    }
    
    /**
     * This method caculates the difference between a value and his neighbors
     * for each position on the map and returns the minimum difference.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return an int of the minimum difference of a value and his neighbors in the map.
     */
    private int diferenceNeighborhood(int fieldmap[][]){
        int min = 9999999;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                int sub = 0;
                if(j+1 <4)
                    sub += fieldmap[i][j] - fieldmap[i][j+1];
                if(j-1 >-1)
                    sub += fieldmap[i][j] - fieldmap[i][j-1];
                if(i+1 <4)
                    sub += fieldmap[i][j] - fieldmap[i+1][j];
                if(i-1>-1)
                    sub += fieldmap[i][j] - fieldmap[i-1][j];
                if(sub<min)
                    min = sub;
            }
        }
        return min;
    }
    
    /**
     * This method returns the max value of the sum of values of each edge in the map.
     * @param fieldmap a 4x4 matrix that represents the board for the next move.
     * @return a int value for the some of the max edge.
     */
    private int maxEdge(int fieldmap[][]){
        int max;
        int sum = 0;
        for(int i =0; i<4;i++){
            sum += fieldmap[0][i];
        }
        max = sum;
        sum = 0;
        for(int i =0; i<4;i++){
            sum += fieldmap[3][i];
        }
        if(sum>max)
            max = sum;
        sum = 0;
        for(int i =0; i<4;i++){
            sum += fieldmap[i][0];
        }
        if(sum>max)
            max = sum;
        sum = 0;
        for(int i =0; i<4;i++){
            sum += fieldmap[i][3];
        }
        if(sum>max)
            max = sum;
        return max;
    }
    
    /**
     * This method returns the highest value in a corner of the map
     * @param fieldmap is the board to search on
     * @return a int that is the highest value between corners
     */
    private int maxCorner(int fieldmap[][]){
        int max = fieldmap[0][0];
        if(max < fieldmap[0][3])
            max = fieldmap[0][3];
        if(max < fieldmap[3][0])
            max = fieldmap[3][0];
        if(max < fieldmap[3][3])
            max = fieldmap[3][3];
        return max;
    }
    
    /**
     * This method randomly assigns a float value for every characteristic for 
     * all individuals in the population
     * @param population is a matrix of floats that repesents the population
     */
    private void initPopulation(float[][] population) {
        for(int i=0; i<20;i++){
            for(int j=0; j<N_CHRO; j++){
                population[i][j] = randomSeed.nextFloat() * randomSeed.nextInt(10);
            }
        }
        if(Save.getFittest() != null){
            System.arraycopy(population[0], 0, Save.getFittest(), 0, N_CHRO);
        }
    }

    /**
     * This method returns if a value will suffer a mutation or not, based on a given rate.
     * @param rate int that represents the chance of a mutation to happen.
     * @return a boolean value that indicates if the mutation will happen or not.
     */
    private boolean mutationRate(int rate) {
        int percent = randomSeed.nextInt(101);
        return percent < rate;
    }
    
    /**
     * This method removes the values above and below the
     * average +- standard deviation, and returns a new
     * average that uses only the remaining values.
     * @param scores This parameter is the scores of the games for one chromosome in one generation.
     * @return double This returns the average of the remaining values after the extreme values are removed.
     */
    private double sdcut(int scores[]){
        
        double avg = 0;
        int count = 0;
        double sum = 0;
        //Calculates the average of all scores for one chromosome
        for(int i=0;i<N_TRY;i++){
            avg += scores[i];
        }
        avg /= N_TRY;
        
        //Calculates the standard deviation for the scores of one chromosome
        for(int i=0;i<N_TRY;i++){
            double dif = scores[i]-avg;
            dif *= dif;
            sum += dif;
        }
        sum /= N_TRY-1;
        double sd = java.lang.Math.sqrt(sum);
        
        //Clears the values too high or too low
        //Counts the number of removed values
        //Sums the remaining values
        sum = 0;
        for(int i=0;i<N_TRY;i++){
            if(scores[i]> avg+sd){
                scores[i]= 0;
                count++;
            }
            else if(scores[i]< avg-sd){
                scores[i]= 0;
                count++;
            }
            else
                sum+= scores[i];
        }
        //Returns the average of the remaining values.
        return sum/(N_TRY-count);
    }
    
    //</editor-fold>
}