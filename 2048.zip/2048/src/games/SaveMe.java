/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package games;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * This class is responsible for saving the best solution found with the evolutionary algorithm
 * @author bruno
 */
public class SaveMe {
    
    float fittest[];
    float score;
    int n_chromosomes;
    
    public SaveMe(int _n_chromosomes){
       n_chromosomes = _n_chromosomes;
       fittest = new float[n_chromosomes];
    }
    
    /**
    * This method saves the best solution found in the file "fittest.txt"
    * @param _fittest is a float array with the coefficients of the best solution
    * @param _score is the average score of the best solution found
    */
    public void saveFittest(float _fittest[], float _score){

        try {
            FileOutputStream f = new FileOutputStream(new File("fittest.txt"));
            ObjectOutputStream o = new ObjectOutputStream(f);
            
            for(int i = 0; i < n_chromosomes; i++)
                o.writeObject(_fittest[i]);
            o.writeObject(_score);
            
            o.close();
            f.close();
            
            
        } catch (FileNotFoundException e) {
                System.out.println("File not found");
        } catch (IOException e) {
                System.out.println("Error initializing stream");
        }
        
    }
    /**
    * This method load the best solution found from the file "fittest.txt"
    */
    public void loadFittest(){
        
        try {
            FileInputStream fi = new FileInputStream(new File("fittest.txt"));
            ObjectInputStream oi = new ObjectInputStream(fi);
            for(int i = 0; i < n_chromosomes; i++)
                this.fittest[i] = (float) oi.readObject();;
            this.score = (float) oi.readObject();
            oi.close();
            fi.close();
        } catch (Exception e) {
            System.out.println("Error loading");
        }
    }
    
    /**
    * This method returns the coefficients of the best solution loaded
    * @return a float array with the coefficients of the best solution loaded
    */
    public float[] getFittest() {
        return fittest;
    }
    /**
    * This method returns the average score of the best solution loaded
    * @return a float with the average score of the best solution loaded
    */
    public float getScore() {
        return score;
    }

}
